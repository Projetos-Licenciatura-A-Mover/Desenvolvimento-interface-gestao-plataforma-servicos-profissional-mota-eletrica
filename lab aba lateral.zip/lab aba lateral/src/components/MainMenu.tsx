import React from 'react';
import { UserRole } from '../types/auth';
import { Truck, Users, Bike } from 'lucide-react';

interface MainMenuProps {
  onMenuClick: (page: 'main' | 'tasks' | 'motorcycles' | 'drivers') => void;
  userRole: UserRole;
}

const MainMenu: React.FC<MainMenuProps> = ({ onMenuClick, userRole }) => {
  const menuItems = [
    { 
      id: 1, 
      label: 'Tarefas/Rotas', 
      page: 'tasks' as const,
      description: 'Gerir tarefas e rotas diárias',
      icon: <Truck className="w-6 h-6 text-blue-600" />
    },
    { 
      id: 2, 
      label: 'Condutores', 
      page: 'drivers' as const,
      description: 'Gestão de condutores',
      icon: <Users className="w-6 h-6 text-green-600" />
    },
    { 
      id: 3, 
      label: 'Motas', 
      page: 'motorcycles' as const,
      description: 'Gestão de Motas',
      icon: <Bike className="w-6 h-6 text-purple-600" />
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {menuItems.map((item) => (
        <button
          key={item.id}
          onClick={() => onMenuClick(item.page)}
          className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-200 text-left"
        >
          <div className="flex items-start gap-4">
            <div className="p-3 bg-gray-50 rounded-lg">
              {item.icon}
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{item.label}</h3>
              <p className="text-sm text-gray-500 mt-1">{item.description}</p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
};

export default MainMenu;