import React from 'react';

const RoutesPage: React.FC = () => {
  return (
    <div className="flex flex-col h-full bg-[#717171] p-4">
      <h1 className="text-2xl font-bold text-white mb-4">Rotas</h1>
    </div>
  );
};

export default RoutesPage;