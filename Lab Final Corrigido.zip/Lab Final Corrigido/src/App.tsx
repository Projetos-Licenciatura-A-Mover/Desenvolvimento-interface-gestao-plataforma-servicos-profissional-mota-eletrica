import { useState, useEffect } from 'react';
import Header from './components/Header';
import MainMenu from './components/MainMenu';
import UserProfile from './components/UserProfile';
import DriversPage from './pages/DriversPage';
import SettingsPage from './pages/SettingsPage';
import AssistancePage from './pages/AssistancePage';
import CalendarPage from './pages/CalendarPage';
import TasksPage from './pages/TasksPage';
import ProfilePage from './pages/ProfilePage';
import LoginPage from './pages/LoginPage';
import RecoverPasswordPage from './pages/RecoverPasswordPage';
import MotorcyclesPage from './pages/MotorcyclesPage';
import MaintenancePage from './pages/MaintenancePage';
import RoutesPage from './pages/RoutesPage';
import { User } from './types/auth';
import { TaskProvider } from './context/TaskContext';
import { Home, ClipboardCheck, Map, Calendar, Settings, LogOut } from 'lucide-react';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<'main' | 'routes' | 'settings' | 'assistance' | 'calendar' | 'tasks' | 'profile' | 'recover' | 'motorcycles' | 'maintenance' | 'drivers'>('main');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 60000);

    return () => clearInterval(interval);
  }, []);

  const getPageTitle = () => {
    switch (currentPage) {
      case 'routes':
        return 'Rotas';
      case 'settings':
        return 'Definições';
      case 'assistance':
        return 'Assistência';
      case 'calendar':
        return 'Calendário';
      case 'tasks':
        return 'Tarefas';
      case 'profile':
        return 'Perfil';
      case 'recover':
        return 'Recuperar Senha';
      case 'motorcycles':
        return 'Gestão de Motas';
      case 'maintenance':
        return 'Manutenções';
      case 'drivers':
        return 'Condutores';
      default:
        return 'Main Page';
    }
  };

  const navItems = [
    { id: 1, icon: <Home size={22} />, label: 'Main Page', page: 'main' as const },
    { id: 2, icon: <ClipboardCheck size={22} />, label: 'Tarefas', page: 'tasks' as const },
    { id: 3, icon: <Map size={22} />, label: 'Rotas', page: 'routes' as const },
    { id: 4, icon: <Calendar size={22} />, label: 'Calendário', page: 'calendar' as const },
    { id: 5, icon: <Settings size={22} />, label: 'Definições', page: 'settings' as const },
  ];

  if (!currentUser) {
    if (currentPage === 'recover') {
      return <RecoverPasswordPage />;
    }
    return <LoginPage onLogin={setCurrentUser} onRecover={() => setCurrentPage('recover')} />;
  }

  const handleLogout = () => {
    // Clear saved login credentials when logging out
    localStorage.removeItem('rememberedLogin');
    setCurrentUser(null);
    setCurrentPage('main');
  };

  const handleLogoClick = () => {
    setCurrentPage('main');
  };

  return (
    <TaskProvider>
      <div className="flex h-screen bg-background">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200">
          <div className="flex justify-center items-center p-6 border-b border-gray-200">
            <button 
              onClick={handleLogoClick}
              className="hover:opacity-80 transition-opacity"
            >
              <img 
                src="https://i.imgur.com/BdLgac3.png"
                alt="A-Mover Logo"
                className="h-12 object-contain"
              />
            </button>
          </div>

          <nav className="p-4 flex flex-col gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.page)}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors ${
                  currentPage === item.page 
                    ? 'bg-gray-100 text-gray-900' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                {item.icon}
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="mt-auto p-4 border-t border-gray-200">
            <button
              onClick={handleLogout}
              className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 w-full"
            >
              <LogOut size={22} />
              <span className="text-sm font-medium">Sair</span>
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          <Header 
            time={currentTime} 
            title={getPageTitle()} 
            user={currentUser}
            onProfileClick={() => setCurrentPage('profile')}
          />
          
          <main className="flex-1 overflow-auto bg-background p-6">
            {currentPage === 'main' && (
              <div className="max-w-7xl mx-auto">
                <MainMenu onMenuClick={(page) => setCurrentPage(page)} userRole={currentUser.role} />
              </div>
            )}
            {currentPage === 'routes' && <RoutesPage />}
            {currentPage === 'settings' && <SettingsPage onMenuClick={setCurrentPage} />}
            {currentPage === 'assistance' && <AssistancePage />}
            {currentPage === 'calendar' && <CalendarPage />}
            {currentPage === 'tasks' && <TasksPage />}
            {currentPage === 'profile' && <ProfilePage />}
            {currentPage === 'motorcycles' && <MotorcyclesPage />}
            {currentPage === 'maintenance' && <MaintenancePage />}
            {currentPage === 'drivers' && <DriversPage />}
          </main>
        </div>
      </div>
    </TaskProvider>
  );
}

export default App;