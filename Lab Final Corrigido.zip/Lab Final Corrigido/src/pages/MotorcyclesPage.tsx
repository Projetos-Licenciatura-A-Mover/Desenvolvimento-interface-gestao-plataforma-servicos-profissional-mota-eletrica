import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { useMotorcycleStore, Motorcycle } from '../types/motorcycle';
import { useDriverStore } from '../types/drivers';

const MotorcyclesPage: React.FC = () => {
  const [selectedMoto, setSelectedMoto] = useState<Motorcycle | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedMotoForAssignment, setSelectedMotoForAssignment] = useState<Motorcycle | null>(null);
  const [newMoto, setNewMoto] = useState({
    matricula: '',
    name: '',
    marca: '',
    modelo: '',
    status: 'Disponível' as const
  });

  const { motorcycles, addMotorcycle, updateMotorcycle, assignMotorcycle } = useMotorcycleStore();
  const { drivers, assignMotorcycle: assignToDriver } = useDriverStore();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Disponível':
        return 'text-green-600';
      case 'Em Uso':
        return 'text-orange-500';
      case 'Manutenção':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusButtonColor = (status: string) => {
    switch (status) {
      case 'Disponível':
        return 'bg-green-600 hover:bg-green-700';
      case 'Em Uso':
        return 'bg-orange-500 hover:bg-orange-600';
      default:
        return 'bg-gray-600 hover:bg-gray-700';
    }
  };

  const handleAddMotorcycle = () => {
    if (newMoto.matricula && newMoto.name) {
      addMotorcycle(newMoto);
      setShowAddModal(false);
      setNewMoto({
        matricula: '',
        name: '',
        marca: '',
        modelo: '',
        status: 'Disponível'
      });
    }
  };

  const handleStatusUpdate = (moto: Motorcycle, newStatus: Motorcycle['status']) => {
    updateMotorcycle(moto.id, { status: newStatus });
  };

  const handleAssignClick = (moto: Motorcycle) => {
    setSelectedMotoForAssignment(moto);
    setShowAssignModal(true);
  };

  const handleAssignToDriver = (motorcycleId: string, driverId: number) => {
    assignMotorcycle(motorcycleId, driverId);
    assignToDriver(driverId, motorcycleId);
    setShowAssignModal(false);
    setSelectedMotoForAssignment(null);
  };

  const availableDrivers = drivers.filter(driver => 
    driver.status === 'active' && !driver.assignedMotorcycleId
  );

  const getAssignedDriverName = (motorcycleId: string) => {
    const assignedDriver = drivers.find(d => d.assignedMotorcycleId === motorcycleId);
    return assignedDriver ? assignedDriver.name : null;
  };

  const getMotorcycleStatusDisplay = (moto: Motorcycle) => {
    if (moto.status === 'Manutenção') return 'Manutenção';
    if (moto.status === 'Em Uso') return 'Em Uso';
    if (moto.assignedDriverId && moto.status === 'Disponível') return 'Atribuída';
    return 'Disponível';
  };

  const getMotorcycleStatusColor = (moto: Motorcycle) => {
    if (moto.status === 'Manutenção') return 'text-red-600';
    if (moto.status === 'Em Uso') return 'text-orange-500';
    if (moto.assignedDriverId && moto.status === 'Disponível') return 'text-blue-600';
    return 'text-green-600';
  };

  const getTaskCount = (moto: Motorcycle) => {
    return moto.assignedTasks ? moto.assignedTasks.length : 0;
  };

  return (
    <div className="flex flex-col h-full bg-background p-6">
      <div className="flex-1 space-y-4 overflow-y-auto">
        {motorcycles.map((moto) => {
          const taskCount = getTaskCount(moto);
          
          return (
            <div
              key={moto.id}
              className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200"
              onClick={() => setSelectedMoto(moto)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{moto.id}</h3>
                    <p className="text-gray-600">{moto.name}</p>
                    <p className="text-sm text-gray-500">Matrícula: {moto.matricula}</p>
                    {moto.assignedDriverId && (
                      <p className="text-sm text-blue-600 mt-1">
                        Condutor: {getAssignedDriverName(moto.id)}
                      </p>
                    )}
                    {taskCount > 0 && (
                      <p className="text-sm text-orange-600 mt-1">
                        {taskCount} tarefa{taskCount !== 1 ? 's' : ''} atribuída{taskCount !== 1 ? 's' : ''}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {moto.status !== 'Manutenção' && !moto.assignedDriverId && (
                    <button
                      className="px-4 py-2 text-white text-sm rounded-lg bg-[#333333] hover:bg-[#444444] transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAssignClick(moto);
                      }}
                    >
                      Atribuir Mota
                    </button>
                  )}
                  <span className={`${getMotorcycleStatusColor(moto)} font-semibold`}>
                    {getMotorcycleStatusDisplay(moto)}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={() => setShowAddModal(true)}
        className="mt-6 bg-[#333333] text-white py-3 px-6 rounded-lg flex items-center justify-center gap-2 hover:bg-[#444444] transition-colors font-medium"
      >
        <Plus size={20} />
        <span>Adicionar Mota</span>
      </button>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Adicionar Nova Mota</h3>
              <button onClick={() => setShowAddModal(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">Matrícula:</label>
                <input
                  type="text"
                  value={newMoto.matricula}
                  onChange={(e) => setNewMoto({ ...newMoto, matricula: e.target.value })}
                  className="w-full border border-gray-300 rounded-md p-2"
                  placeholder="XX-XX-XX"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-1">Nome:</label>
                <input
                  type="text"
                  value={newMoto.name}
                  onChange={(e) => setNewMoto({ ...newMoto, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-md p-2"
                  placeholder="Nome da mota"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-1">Marca:</label>
                <input
                  type="text"
                  value={newMoto.marca}
                  onChange={(e) => setNewMoto({ ...newMoto, marca: e.target.value })}
                  className="w-full border border-gray-300 rounded-md p-2"
                  placeholder="Marca da mota"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-1">Modelo:</label>
                <input
                  type="text"
                  value={newMoto.modelo}
                  onChange={(e) => setNewMoto({ ...newMoto, modelo: e.target.value })}
                  className="w-full border border-gray-300 rounded-md p-2"
                  placeholder="Modelo da mota"
                />
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  className="flex-1 px-4 py-2 bg-gray-200 rounded-lg text-gray-800 font-medium"
                  onClick={() => setShowAddModal(false)}
                >
                  Cancelar
                </button>
                <button
                  className="flex-1 px-4 py-2 bg-[#333333] text-white rounded-lg font-medium"
                  onClick={handleAddMotorcycle}
                >
                  Adicionar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {selectedMoto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Detalhes da Mota</h3>
              <button onClick={() => setSelectedMoto(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">Nome:</label>
                <input
                  type="text"
                  value={selectedMoto.name}
                  className="w-full border border-gray-300 rounded-md p-2"
                  readOnly
                />
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-1">Matrícula:</label>
                <input
                  type="text"
                  value={selectedMoto.matricula}
                  className="w-full border border-gray-300 rounded-md p-2"
                  readOnly
                />
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-1">Marca:</label>
                <input
                  type="text"
                  value={selectedMoto.marca}
                  className="w-full border border-gray-300 rounded-md p-2"
                  readOnly
                />
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-1">Modelo:</label>
                <input
                  type="text"
                  value={selectedMoto.modelo}
                  className="w-full border border-gray-300 rounded-md p-2"
                  readOnly
                />
              </div>

              {selectedMoto.assignedDriverId && (
                <div>
                  <label className="block text-sm text-gray-600 mb-1">Condutor Atribuído:</label>
                  <input
                    type="text"
                    value={getAssignedDriverName(selectedMoto.id) || ''}
                    className="w-full border border-gray-300 rounded-md p-2 bg-gray-50"
                    readOnly
                  />
                </div>
              )}

              <div>
                <label className="block text-sm text-gray-600 mb-1">Status Atual:</label>
                <div className={`px-3 py-2 rounded-md text-center font-medium ${getMotorcycleStatusColor(selectedMoto)}`}>
                  {getMotorcycleStatusDisplay(selectedMoto)}
                </div>
              </div>

              {getTaskCount(selectedMoto) > 0 && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                  <p className="text-sm text-orange-800 font-medium">
                    Esta mota tem {getTaskCount(selectedMoto)} tarefa{getTaskCount(selectedMoto) !== 1 ? 's' : ''} atribuída{getTaskCount(selectedMoto) !== 1 ? 's' : ''}
                  </p>
                </div>
              )}

              {/* Only show status update buttons if motorcycle is not in maintenance, not assigned to driver, and doesn't have tasks */}
              {selectedMoto.status !== 'Manutenção' && !selectedMoto.assignedDriverId && getTaskCount(selectedMoto) === 0 && (
                <div className="mt-6">
                  <h4 className="font-medium mb-3">Atualizar Status da Mota</h4>
                  <div className="space-y-2">
                    {(['Disponível', 'Em Uso'] as const).map((status) => (
                      <button
                        key={status}
                        className={`w-full py-2 text-white rounded-md ${getStatusButtonColor(status)}`}
                        onClick={() => {
                          handleStatusUpdate(selectedMoto, status);
                          setSelectedMoto(null);
                        }}
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                className="w-full mt-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
                onClick={() => setSelectedMoto(null)}
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Assign Modal */}
      {showAssignModal && selectedMotoForAssignment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Atribuir Mota a Condutor</h3>
              <button onClick={() => {
                setShowAssignModal(false);
                setSelectedMotoForAssignment(null);
              }}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <h4 className="font-medium text-gray-700">Mota Selecionada:</h4>
                <p className="text-sm text-gray-600">{selectedMotoForAssignment.name}</p>
                <p className="text-xs text-gray-500">Matrícula: {selectedMotoForAssignment.matricula}</p>
              </div>

              <div className="space-y-3">
                <h4 className="font-medium text-gray-700">Condutores Disponíveis:</h4>
                {availableDrivers.length > 0 ? (
                  availableDrivers.map(driver => (
                    <button
                      key={driver.id}
                      className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      onClick={() => handleAssignToDriver(selectedMotoForAssignment.id, driver.id)}
                    >
                      <div className="font-medium">{driver.name}</div>
                      <div className="text-sm text-gray-500">{driver.license}</div>
                    </button>
                  ))
                ) : (
                  <p className="text-center text-gray-500 py-4">
                    Não há condutores disponíveis no momento
                  </p>
                )}
              </div>

              <button
                className="w-full mt-6 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg font-medium"
                onClick={() => {
                  setShowAssignModal(false);
                  setSelectedMotoForAssignment(null);
                }}
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MotorcyclesPage;