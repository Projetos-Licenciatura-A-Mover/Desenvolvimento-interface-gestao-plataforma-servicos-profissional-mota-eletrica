import React, { useState } from 'react';
import { MapPin, Clock, Calendar, ChevronLeft, ChevronRight, Filter, X, User, ArrowLeft, Trash2, AlertTriangle } from 'lucide-react';
import { useTasks } from '../context/TaskContext';
import { Task } from '../types/tasks';
import { useMotorcycleStore } from '../types/motorcycle';
import { useDriverStore } from '../types/drivers';

const RoutesPage: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedDriverTasks, setSelectedDriverTasks] = useState<{
    driverName: string;
    motorcycleName: string;
    motorcycleId: string;
    tasks: Task[];
    hasDriver: boolean;
  } | null>(null);
  
  const { getTasksByDate, tasks: allTasks } = useTasks();
  const { motorcycles, assignTaskToMotorcycle, removeTaskFromMotorcycle, clearAllTasks } = useMotorcycleStore();
  const { drivers } = useDriverStore();

  const formatDate = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const tasks = getTasksByDate(formatDate(selectedDate));

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'ALTA':
        return 'bg-red-500';
      case 'MÉDIA':
        return 'bg-orange-500';
      case 'BAIXA':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getTypeColor = (type: string) => {
    return type === 'Entrega' ? 'text-blue-600' : 'text-purple-600';
  };

  const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const daysInMonth = new Date(
    selectedDate.getFullYear(),
    selectedDate.getMonth() + 1,
    0
  ).getDate();

  const firstDayOfMonth = new Date(
    selectedDate.getFullYear(),
    selectedDate.getMonth(),
    1
  ).getDay();

  const handlePrevMonth = () => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1));
  };

  const handleDayClick = (day: number) => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day));
  };

  const getTasksForDate = (date: Date) => {
    return getTasksByDate(formatDate(date));
  };

  const handleAssignTask = (motorcycleId: string) => {
    if (selectedTask) {
      assignTaskToMotorcycle(motorcycleId, selectedTask.id);
      setShowAssignModal(false);
      setSelectedTask(null);
    }
  };

  // Get all motorcycles that are not in maintenance (regardless of driver assignment)
  const getAvailableMotorcycles = () => {
    return motorcycles.filter(moto => moto.status !== 'Manutenção');
  };

  const getMotorcycleTasks = (motorcycleId: string) => {
    const motorcycle = motorcycles.find(m => m.id === motorcycleId);
    if (!motorcycle || !motorcycle.assignedTasks) return [];
    
    return allTasks.filter(task => motorcycle.assignedTasks!.includes(task.id));
  };

  const getDriverName = (motorcycleId: string) => {
    const motorcycle = motorcycles.find(m => m.id === motorcycleId);
    if (!motorcycle?.assignedDriverId) return '';
    
    const driver = drivers.find(d => d.id === motorcycle.assignedDriverId);
    return driver ? driver.name : '';
  };

  const handleMotorcycleClick = (motorcycleId: string) => {
    const motorcycle = motorcycles.find(m => m.id === motorcycleId);
    const driverName = getDriverName(motorcycleId);
    const assignedTasks = getMotorcycleTasks(motorcycleId);
    const hasDriver = !!motorcycle?.assignedDriverId;
    
    if (motorcycle) {
      setSelectedDriverTasks({
        driverName: hasDriver ? driverName : 'Sem Condutor',
        motorcycleName: motorcycle.name,
        motorcycleId: motorcycle.id,
        tasks: assignedTasks,
        hasDriver
      });
    }
  };

  const handleRemoveTask = (motorcycleId: string, taskId: number) => {
    removeTaskFromMotorcycle(motorcycleId, taskId);
    
    // Update the selected driver tasks if we're viewing them
    if (selectedDriverTasks && selectedDriverTasks.motorcycleId === motorcycleId) {
      const updatedTasks = selectedDriverTasks.tasks.filter(task => task.id !== taskId);
      setSelectedDriverTasks({
        ...selectedDriverTasks,
        tasks: updatedTasks
      });
    }
  };

  const handleClearAllTasks = (motorcycleId: string) => {
    clearAllTasks(motorcycleId);
    
    // Update the selected driver tasks if we're viewing them
    if (selectedDriverTasks && selectedDriverTasks.motorcycleId === motorcycleId) {
      setSelectedDriverTasks({
        ...selectedDriverTasks,
        tasks: []
      });
    }
  };

  const renderDriverTasksView = () => {
    if (!selectedDriverTasks) return null;

    return (
      <div className="w-1/3 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <button
              onClick={() => setSelectedDriverTasks(null)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} className="text-gray-600" />
            </button>
            <div className="flex-1">
              <h2 className="text-xl font-semibold">Tarefas Atribuídas</h2>
              <div className="flex items-center gap-2">
                <p className="text-sm text-gray-600">
                  {selectedDriverTasks.motorcycleName}
                </p>
                {!selectedDriverTasks.hasDriver && (
                  <div className="flex items-center gap-1 px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs">
                    <AlertTriangle size={12} />
                    <span>Mota Sem Condutor</span>
                  </div>
                )}
              </div>
              {selectedDriverTasks.hasDriver && (
                <p className="text-sm text-blue-600">
                  Condutor: {selectedDriverTasks.driverName}
                </p>
              )}
            </div>
          </div>
          
          {selectedDriverTasks.tasks.length > 0 && (
            <button
              onClick={() => handleClearAllTasks(selectedDriverTasks.motorcycleId)}
              className="w-full px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
            >
              Limpar Todas as Tarefas
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {selectedDriverTasks.tasks.length > 0 ? (
            <div className="space-y-4">
              {selectedDriverTasks.tasks.map((task, index) => (
                <div
                  key={task.id}
                  className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-[#333333] text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      <h3 className="font-medium">{task.title}</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`px-2 py-1 rounded-full text-white text-xs ${getPriorityColor(task.priority)}`}>
                        {task.priority}
                      </div>
                      <button
                        onClick={() => handleRemoveTask(selectedDriverTasks.motorcycleId, task.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Remover tarefa"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin size={16} className="text-gray-500" />
                      <span className="text-gray-600">{task.address}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock size={16} className="text-gray-500" />
                      <span className="text-gray-600">{task.time}</span>
                      <span className={`ml-2 font-medium ${getTypeColor(task.type)}`}>
                        {task.type}
                      </span>
                    </div>
                    <div className="mt-3 p-2 bg-gray-50 rounded-md">
                      <p className="text-xs text-gray-600">Horário disponível:</p>
                      <p className="text-sm font-medium">{task.availableTime}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-500 py-8">
              <User size={48} className="mx-auto mb-4 text-gray-300" />
              <p>Nenhuma tarefa atribuída</p>
              <p className="text-sm">Esta mota ainda não tem tarefas para hoje</p>
            </div>
          )}
        </div>

        {selectedDriverTasks.tasks.length > 0 && (
          <div className="border-t border-gray-200 p-4">
            <div className={`rounded-lg p-3 ${selectedDriverTasks.hasDriver ? 'bg-blue-50' : 'bg-orange-50'}`}>
              <div className="flex items-center justify-between text-sm">
                <span className={`font-medium ${selectedDriverTasks.hasDriver ? 'text-blue-700' : 'text-orange-700'}`}>
                  Total de tarefas:
                </span>
                <span className={`font-semibold ${selectedDriverTasks.hasDriver ? 'text-blue-900' : 'text-orange-900'}`}>
                  {selectedDriverTasks.tasks.length}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm mt-1">
                <span className={selectedDriverTasks.hasDriver ? 'text-blue-700' : 'text-orange-700'}>
                  Tempo estimado:
                </span>
                <span className={selectedDriverTasks.hasDriver ? 'text-blue-900' : 'text-orange-900'}>
                  {selectedDriverTasks.tasks.length * 30} min
                </span>
              </div>
              {!selectedDriverTasks.hasDriver && (
                <div className="mt-2 pt-2 border-t border-orange-200">
                  <div className="flex items-center gap-1 text-xs text-orange-700">
                    <AlertTriangle size={12} />
                    <span>Atenção: Esta mota não tem condutor atribuído</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex h-full">
      {/* Left Panel - Tasks or Driver Tasks */}
      {selectedDriverTasks ? (
        renderDriverTasksView()
      ) : (
        <div className="w-1/3 bg-white border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">
                Tarefas para {selectedDate.toLocaleDateString('pt-BR')}
              </h2>
              <button
                onClick={() => setShowFilters(true)}
                className="p-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                <Filter size={20} className="text-gray-600" />
              </button>
            </div>
            <input
              type="text"
              placeholder="Pesquisar tarefas..."
              className="w-full px-4 py-2 border border-gray-300 rounded-md"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {tasks.map(task => {
              // Check if task is already assigned to any motorcycle
              const isAssigned = motorcycles.some(moto => 
                moto.assignedTasks && moto.assignedTasks.includes(task.id)
              );
              
              return (
                <div
                  key={task.id}
                  className={`bg-white rounded-lg border p-4 cursor-pointer hover:border-gray-300 hover:shadow-sm transition-all ${
                    isAssigned ? 'border-green-300 bg-green-50' : 'border-gray-200'
                  }`}
                  onClick={() => setSelectedTask(task)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium">{task.title}</h3>
                    <div className="flex items-center gap-2">
                      {isAssigned && (
                        <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                          Atribuída
                        </span>
                      )}
                      <div className={`px-2 py-1 rounded-full text-white text-xs ${getPriorityColor(task.priority)}`}>
                        {task.priority}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin size={16} className="text-gray-500" />
                      <span className="text-gray-600">{task.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock size={16} className="text-gray-500" />
                      <span className="text-gray-600">{task.time}</span>
                      <span className={`ml-2 font-medium ${getTypeColor(task.type)}`}>
                        {task.type}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
            {tasks.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                <Calendar size={48} className="mx-auto mb-4 text-gray-300" />
                <p>Nenhuma tarefa para esta data</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Middle Panel - Routes */}
      <div className="w-1/3 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Rotas Atribuídas</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {getAvailableMotorcycles().map(moto => {
            const assignedTasks = getMotorcycleTasks(moto.id);
            const driverName = getDriverName(moto.id);
            const hasDriver = !!moto.assignedDriverId;
            
            return (
              <div key={moto.id} className="mb-6">
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <h3 className="font-medium">{moto.name}</h3>
                    <button
                      onClick={() => handleMotorcycleClick(moto.id)}
                      className={`text-sm hover:underline transition-colors ${
                        hasDriver ? 'text-blue-600 hover:text-blue-800' : 'text-orange-600 hover:text-orange-800'
                      }`}
                    >
                      {hasDriver ? `Condutor: ${driverName}` : 'Mota Sem Condutor'}
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    {!hasDriver && (
                      <div className="flex items-center gap-1 px-2 py-1 bg-orange-100 text-orange-600 rounded-full text-xs">
                        <AlertTriangle size={12} />
                        <span>Sem Condutor</span>
                      </div>
                    )}
                    <span className={`px-3 py-1 text-sm rounded-full ${
                      assignedTasks.length > 0
                        ? 'bg-orange-100 text-orange-600' 
                        : hasDriver 
                          ? 'bg-blue-100 text-blue-600' 
                          : 'bg-gray-100 text-gray-600'
                    }`}>
                      {assignedTasks.length > 0 ? 'Em Uso' : hasDriver ? 'Atribuída' : 'Disponível'}
                    </span>
                    {assignedTasks.length > 0 && (
                      <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                        {assignedTasks.length} tarefa{assignedTasks.length !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  {assignedTasks.map((task, index) => (
                    <div
                      key={task.id}
                      className="bg-gray-50 rounded-lg p-3 border border-gray-200"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-[#333333] text-white rounded-full flex items-center justify-center text-xs font-medium">
                            {index + 1}
                          </div>
                          <h4 className="font-medium">{task.title}</h4>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">{task.time}</span>
                          <button
                            onClick={() => handleRemoveTask(moto.id, task.id)}
                            className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Remover tarefa"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 ml-8">{task.location}</p>
                    </div>
                  ))}
                  {assignedTasks.length === 0 && (
                    <div className="bg-gray-50 rounded-lg p-3 border border-gray-200 text-center text-gray-500 text-sm">
                      Nenhuma tarefa atribuída
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {getAvailableMotorcycles().length === 0 && (
            <div className="text-center text-gray-500 py-8">
              <User size={48} className="mx-auto mb-4 text-gray-300" />
              <p>Nenhuma mota disponível</p>
              <p className="text-sm">Todas as motas estão em manutenção</p>
            </div>
          )}
        </div>
      </div>

      {/* Right Panel - Calendar */}
      <div className="w-1/3 bg-white flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <button onClick={handlePrevMonth} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-semibold">
              {monthNames[selectedDate.getMonth()]} {selectedDate.getFullYear()}
            </h2>
            <button onClick={handleNextMonth} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {weekDays.map(day => (
              <div key={day} className="text-center font-medium text-sm py-2 text-gray-600">
                {day}
              </div>
            ))}
          </div>
        </div>

        <div className="flex-1 p-4">
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDayOfMonth }).map((_, index) => (
              <div key={`empty-${index}`} className="aspect-square" />
            ))}
            
            {Array.from({ length: daysInMonth }).map((_, index) => {
              const day = index + 1;
              const currentDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
              const isSelected = currentDate.toDateString() === selectedDate.toDateString();
              const isToday = new Date().toDateString() === currentDate.toDateString();
              const hasEvents = getTasksForDate(currentDate).length > 0;

              return (
                <button
                  key={day}
                  onClick={() => handleDayClick(day)}
                  className={`aspect-square border p-2 flex flex-col transition-all hover:shadow-sm ${
                    isSelected
                      ? 'bg-[#333333] text-white border-[#333333] shadow-md'
                      : isToday
                      ? 'bg-blue-50 border-blue-200 text-blue-900'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  <span className={`text-sm ${isSelected ? 'font-medium' : ''}`}>
                    {day}
                  </span>
                  {hasEvents && (
                    <div className="flex-1 flex items-end justify-center">
                      <div className={`w-2 h-2 rounded-full ${
                        isSelected ? 'bg-white' : 'bg-blue-500'
                      }`} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {selectedTask && (
          <div className="border-t border-gray-200 p-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-semibold text-lg">{selectedTask.title}</h3>
                <p className="text-sm text-gray-600">{selectedTask.address}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-white text-sm ${getPriorityColor(selectedTask.priority)}`}>
                {selectedTask.priority}
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Clock size={18} className="text-gray-500" />
                <span>{selectedTask.time}</span>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-600 mb-1">Horário disponível:</p>
                <p className="text-sm font-medium">{selectedTask.availableTime}</p>
              </div>
              
              {/* Check if task is already assigned */}
              {motorcycles.some(moto => moto.assignedTasks && moto.assignedTasks.includes(selectedTask.id)) ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-sm text-green-800 font-medium">
                    Esta tarefa já está atribuída a uma mota
                  </p>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button 
                    className="flex-1 bg-[#333333] text-white py-2 rounded-md hover:bg-[#444444] transition-colors font-medium"
                    onClick={() => setShowAssignModal(true)}
                  >
                    Atribuir Tarefa
                  </button>
                  <button 
                    className="flex-1 border border-gray-300 py-2 rounded-md hover:bg-gray-50 transition-colors"
                    onClick={() => setSelectedTask(null)}
                  >
                    Cancelar
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Assign Task Modal */}
      {showAssignModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Atribuir Tarefa</h3>
              <button onClick={() => setShowAssignModal(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4">
              <h4 className="font-medium mb-4">Motas Disponíveis</h4>
              <div className="space-y-2">
                {getAvailableMotorcycles().map(moto => {
                  const assignedTasksCount = getMotorcycleTasks(moto.id).length;
                  const driverName = getDriverName(moto.id);
                  const hasDriver = !!moto.assignedDriverId;
                  
                  return (
                    <button
                      key={moto.id}
                      className="w-full p-3 border border-gray-200 rounded-lg hover:bg-gray-50 text-left transition-colors"
                      onClick={() => handleAssignTask(moto.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-medium">{moto.name}</div>
                          <div className={`text-sm ${hasDriver ? 'text-blue-600' : 'text-orange-600'}`}>
                            {hasDriver ? `Condutor: ${driverName}` : 'Mota Sem Condutor'}
                          </div>
                          <div className="text-xs text-gray-400">
                            {assignedTasksCount > 0 
                              ? `${assignedTasksCount} tarefa${assignedTasksCount !== 1 ? 's' : ''} atribuída${assignedTasksCount !== 1 ? 's' : ''}`
                              : 'Nenhuma tarefa atribuída'
                            }
                          </div>
                        </div>
                        {!hasDriver && (
                          <div className="flex items-center gap-1 px-2 py-1 bg-orange-100 text-orange-600 rounded-full text-xs ml-2">
                            <AlertTriangle size={10} />
                            <span>Sem Condutor</span>
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
                {getAvailableMotorcycles().length === 0 && (
                  <div className="text-center text-gray-500 py-8">
                    <User size={48} className="mx-auto mb-4 text-gray-300" />
                    <p>Não há motas disponíveis no momento</p>
                    <p className="text-sm">Todas as motas estão em manutenção</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters Modal */}
      {showFilters && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Filtros</h3>
              <button onClick={() => setShowFilters(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Prioridade
                </label>
                <select className="w-full border border-gray-300 rounded-md p-2">
                  <option value="">Todas</option>
                  <option value="ALTA">Alta</option>
                  <option value="MÉDIA">Média</option>
                  <option value="BAIXA">Baixa</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo
                </label>
                <select className="w-full border border-gray-300 rounded-md p-2">
                  <option value="">Todos</option>
                  <option value="Entrega">Entrega</option>
                  <option value="Recolha">Recolha</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select className="w-full border border-gray-300 rounded-md p-2">
                  <option value="">Todos</option>
                  <option value="POR CONCLUIR">Por Concluir</option>
                  <option value="CONCLUÍDO">Concluído</option>
                </select>
              </div>
              <button
                className="w-full bg-[#333333] text-white py-2 rounded-md hover:bg-[#444444] transition-colors"
                onClick={() => setShowFilters(false)}
              >
                Aplicar Filtros
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoutesPage;