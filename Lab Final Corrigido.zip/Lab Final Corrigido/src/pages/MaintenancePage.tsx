import React, { useState } from 'react';
import { Search, AlertCircle, X, CheckCircle } from 'lucide-react';
import { useMotorcycleStore } from '../types/motorcycle';

const MaintenancePage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMoto, setSelectedMoto] = useState<string | null>(null);
  const [maintenanceReason, setMaintenanceReason] = useState('');
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [selectedMotoForRemoval, setSelectedMotoForRemoval] = useState<string | null>(null);
  
  const { motorcycles, setMaintenanceStatus, updateMotorcycle } = useMotorcycleStore();

  const filteredMotorcycles = motorcycles.filter(moto =>
    moto.matricula.toLowerCase().includes(searchTerm.toLowerCase()) ||
    moto.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleMaintenanceSubmit = () => {
    if (selectedMoto && maintenanceReason) {
      setMaintenanceStatus(selectedMoto, maintenanceReason);
      setSelectedMoto(null);
      setMaintenanceReason('');
    }
  };

  const handleRemoveFromMaintenance = () => {
    if (selectedMotoForRemoval) {
      updateMotorcycle(selectedMotoForRemoval, {
        status: 'Disponível',
        maintenanceReason: undefined,
        maintenanceDate: undefined
      });
      setSelectedMotoForRemoval(null);
      setShowRemoveModal(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background p-4">
      {/* Search Section */}
      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Pesquisar por matrícula..."
            className="w-full bg-white rounded-md py-2 pl-10 pr-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
        </div>
      </div>

      {/* Motorcycles List */}
      <div className="flex-1 space-y-4 overflow-y-auto">
        <div className="bg-white rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-4">Motas em Manutenção</h2>
          <div className="space-y-3">
            {filteredMotorcycles
              .filter(moto => moto.status === 'Manutenção')
              .map(moto => (
                <div
                  key={moto.id}
                  className="border border-gray-200 rounded-lg p-4"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{moto.name}</h3>
                      <p className="text-sm text-gray-500">Matrícula: {moto.matricula}</p>
                      <p className="text-sm text-gray-500">Motivo: {moto.maintenanceReason}</p>
                      <p className="text-sm text-gray-500">Data: {moto.maintenanceDate}</p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className="px-3 py-1 bg-red-100 text-red-600 rounded-full text-sm">
                        Em Manutenção
                      </span>
                      <button
                        onClick={() => {
                          setSelectedMotoForRemoval(moto.id);
                          setShowRemoveModal(true);
                        }}
                        className="text-sm text-blue-600 hover:text-blue-800"
                      >
                        Remover da Manutenção
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        <div className="bg-white rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-4">Motas Disponíveis</h2>
          <div className="space-y-3">
            {filteredMotorcycles
              .filter(moto => moto.status !== 'Manutenção')
              .map(moto => (
                <div
                  key={moto.id}
                  className="border border-gray-200 rounded-lg p-4 cursor-pointer hover:border-gray-300"
                  onClick={() => setSelectedMoto(moto.id)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{moto.name}</h3>
                      <p className="text-sm text-gray-500">Matrícula: {moto.matricula}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      moto.status === 'Disponível' 
                        ? 'bg-green-100 text-green-600'
                        : 'bg-orange-100 text-orange-600'
                    }`}>
                      {moto.status}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* Maintenance Modal */}
      {selectedMoto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Enviar para Manutenção</h3>
              <button onClick={() => setSelectedMoto(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle size={20} className="text-orange-500" />
                  <span className="text-sm text-gray-600">
                    Está a enviar para manutenção:
                  </span>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  {motorcycles.find(m => m.id === selectedMoto) && (
                    <>
                      <h4 className="font-medium">{motorcycles.find(m => m.id === selectedMoto)?.name}</h4>
                      <p className="text-sm text-gray-500">
                        Matrícula: {motorcycles.find(m => m.id === selectedMoto)?.matricula}
                      </p>
                    </>
                  )}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Motivo da Manutenção
                </label>
                <textarea
                  value={maintenanceReason}
                  onChange={(e) => setMaintenanceReason(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg p-3 h-32"
                  placeholder="Descreva o motivo da manutenção..."
                />
              </div>

              <div className="flex gap-3">
                <button
                  className="flex-1 px-4 py-2 bg-gray-200 rounded-lg text-gray-800 font-medium"
                  onClick={() => setSelectedMoto(null)}
                >
                  Cancelar
                </button>
                <button
                  className="flex-1 px-4 py-2 bg-[#333333] text-white rounded-lg font-medium disabled:opacity-50"
                  onClick={handleMaintenanceSubmit}
                  disabled={!maintenanceReason}
                >
                  Confirmar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Remove from Maintenance Modal */}
      {showRemoveModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Remover da Manutenção</h3>
              <button onClick={() => {
                setShowRemoveModal(false);
                setSelectedMotoForRemoval(null);
              }}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle size={20} className="text-green-500" />
                  <span className="text-sm text-gray-600">
                    Está a remover da manutenção:
                  </span>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  {motorcycles.find(m => m.id === selectedMotoForRemoval) && (
                    <>
                      <h4 className="font-medium">{motorcycles.find(m => m.id === selectedMotoForRemoval)?.name}</h4>
                      <p className="text-sm text-gray-500">
                        Matrícula: {motorcycles.find(m => m.id === selectedMotoForRemoval)?.matricula}
                      </p>
                    </>
                  )}
                </div>
              </div>

              <p className="text-sm text-gray-600 mb-6">
                Ao confirmar, a mota será marcada como disponível e poderá ser utilizada novamente.
              </p>

              <div className="flex gap-3">
                <button
                  className="flex-1 px-4 py-2 bg-gray-200 rounded-lg text-gray-800 font-medium"
                  onClick={() => {
                    setShowRemoveModal(false);
                    setSelectedMotoForRemoval(null);
                  }}
                >
                  Cancelar
                </button>
                <button
                  className="flex-1 px-4 py-2 bg-[#333333] text-white rounded-lg font-medium"
                  onClick={handleRemoveFromMaintenance}
                >
                  Confirmar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MaintenancePage;