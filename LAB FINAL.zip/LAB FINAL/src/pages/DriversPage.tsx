import React, { useState } from 'react';
import { User, Plus, X, Clock } from 'lucide-react';
import { useDriverStore } from '../types/drivers';
import { useMotorcycleStore } from '../types/motorcycle';

const DriversPage: React.FC = () => {
  const { drivers, addDriver, unassignMotorcycle: unassignFromDriver } = useDriverStore();
  const { motorcycles, unassignMotorcycle } = useMotorcycleStore();
  const [selectedDriver, setSelectedDriver] = useState<number | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newDriver, setNewDriver] = useState({
    name: '',
    license: '',
    phone: '',
    email: '',
    address: '',
    citizenId: '',
    status: 'active' as const
  });

  const handleUnassignMotorcycle = (driverId: number, motorcycleId: string) => {
    unassignFromDriver(driverId);
    unassignMotorcycle(motorcycleId);
  };

  const handleAddDriver = () => {
    if (newDriver.name && newDriver.license && newDriver.phone && newDriver.email) {
      addDriver(newDriver);
      setNewDriver({
        name: '',
        license: '',
        phone: '',
        email: '',
        address: '',
        citizenId: '',
        status: 'active'
      });
      setShowAddModal(false);
    }
  };

  const resetForm = () => {
    setNewDriver({
      name: '',
      license: '',
      phone: '',
      email: '',
      address: '',
      citizenId: '',
      status: 'active'
    });
    setShowAddModal(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#d6d6d6] p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {drivers.map((driver) => {
          const assignedMotorcycle = driver.assignedMotorcycleId 
            ? motorcycles.find(m => m.id === driver.assignedMotorcycleId)
            : null;
          
          return (
            <div
              key={driver.id}
              className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setSelectedDriver(driver.id)}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-gray-100 rounded-full p-4">
                  <User size={32} className="text-gray-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{driver.name}</h3>
                  <p className="text-sm text-gray-500">Licença: {driver.license}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-gray-600">
                  <span className="text-sm">Email: {driver.email}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <span className="text-sm">Telefone: {driver.phone}</span>
                </div>
                {assignedMotorcycle && (
                  <div className="mt-2 p-2 bg-blue-50 rounded-md">
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-blue-600">
                        Mota atribuída: {assignedMotorcycle.name} ({assignedMotorcycle.matricula})
                      </p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleUnassignMotorcycle(driver.id, assignedMotorcycle.id);
                        }}
                        className="text-xs text-red-600 hover:text-red-800 px-2 py-1 bg-red-50 rounded-md"
                      >
                        Desatribuir
                      </button>
                    </div>
                  </div>
                )}
              </div>
              <div className="mt-4">
                <span className={`px-3 py-1 rounded-full text-sm ${
                  driver.status === 'active'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {driver.status === 'active' ? 'Ativo' : 'Inativo'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-6 right-6 bg-[#333333] text-white p-4 rounded-full shadow-lg hover:bg-gray-700 transition-colors"
      >
        <Plus size={24} />
      </button>

      {/* Driver History Modal */}
      {selectedDriver && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-2xl">
            <div className="flex justify-between items-center p-4 border-b">
              <div>
                <h3 className="font-semibold text-xl">{drivers.find(d => d.id === selectedDriver)?.name}</h3>
                <p className="text-sm text-gray-500">Histórico de Serviços</p>
              </div>
              <button onClick={() => setSelectedDriver(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              {drivers.find(d => d.id === selectedDriver)?.assignedMotorcycleId && (
                <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-800 mb-2">Mota Atual</h4>
                  {(() => {
                    const driver = drivers.find(d => d.id === selectedDriver);
                    const motorcycle = driver?.assignedMotorcycleId 
                      ? motorcycles.find(m => m.id === driver.assignedMotorcycleId)
                      : null;
                    return motorcycle ? (
                      <div>
                        <p className="text-blue-600">{motorcycle.name}</p>
                        <p className="text-sm text-blue-500">Matrícula: {motorcycle.matricula}</p>
                      </div>
                    ) : null;
                  })()}
                </div>
              )}

              <div className="space-y-4">
                {drivers.find(d => d.id === selectedDriver)?.schedules.map((schedule) => (
                  <div key={schedule.id} className="border-b pb-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Clock size={18} className="text-gray-500" />
                        <span className="font-medium">{schedule.date}</span>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm ${
                        schedule.status === 'active'
                          ? 'bg-blue-100 text-blue-800'
                          : schedule.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {schedule.status === 'active' ? 'Em Andamento' : 
                         schedule.status === 'completed' ? 'Concluído' : 'Cancelado'}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>Início: {schedule.startTime}</p>
                      <p>Fim: {schedule.endTime}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Driver Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-semibold">Adicionar Novo Condutor</h3>
              <button onClick={resetForm}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-600 mb-1">Nome: *</label>
                  <input
                    type="text"
                    value={newDriver.name}
                    onChange={(e) => setNewDriver({ ...newDriver, name: e.target.value })}
                    className="w-full border border-gray-300 rounded-md p-2"
                    placeholder="Nome completo do condutor"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-1">Licença: *</label>
                  <input
                    type="text"
                    value={newDriver.license}
                    onChange={(e) => setNewDriver({ ...newDriver, license: e.target.value })}
                    className="w-full border border-gray-300 rounded-md p-2"
                    placeholder="Número da carta de condução"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-1">Telefone: *</label>
                  <input
                    type="tel"
                    value={newDriver.phone}
                    onChange={(e) => setNewDriver({ ...newDriver, phone: e.target.value })}
                    className="w-full border border-gray-300 rounded-md p-2"
                    placeholder="Número de telefone"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-1">Email: *</label>
                  <input
                    type="email"
                    value={newDriver.email}
                    onChange={(e) => setNewDriver({ ...newDriver, email: e.target.value })}
                    className="w-full border border-gray-300 rounded-md p-2"
                    placeholder="Endereço de email"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-1">Morada:</label>
                  <input
                    type="text"
                    value={newDriver.address}
                    onChange={(e) => setNewDriver({ ...newDriver, address: e.target.value })}
                    className="w-full border border-gray-300 rounded-md p-2"
                    placeholder="Morada completa"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-1">Cartão de Cidadão:</label>
                  <input
                    type="text"
                    value={newDriver.citizenId}
                    onChange={(e) => setNewDriver({ ...newDriver, citizenId: e.target.value })}
                    className="w-full border border-gray-300 rounded-md p-2"
                    placeholder="Número do cartão de cidadão"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  className="flex-1 px-4 py-2 bg-gray-200 rounded-lg text-gray-800 font-medium"
                  onClick={resetForm}
                >
                  Cancelar
                </button>
                <button
                  className="flex-1 px-4 py-2 bg-[#333333] text-white rounded-lg font-medium disabled:opacity-50"
                  onClick={handleAddDriver}
                  disabled={!newDriver.name || !newDriver.license || !newDriver.phone || !newDriver.email}
                >
                  Adicionar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DriversPage;